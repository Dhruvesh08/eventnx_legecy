﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using System.Data.Entity;
using LinkedInDemo.Models;
using System.Collections;

namespace LinkedInDemo.Controllers
{
    public class RegisteredUserController : Controller
    {
       
            protected static string name = "";
            protected static string pas = "";
            protected static string StatusMessage = "";
            protected static string Message = "";
            private const int FirstPageIndex = 1;
            protected static int TotalDataCount;

            protected static Array Arr;
            protected static bool IsArray;
            protected static IEnumerable BindData;
            private EventRegistrationEntities db = new EventRegistrationEntities();
            public ActionResult Index()
            {
                return View();
            }

            public ActionResult UserGrid(int IsBindData = 1, int currentPageIndex = 1, string orderby = "UserId", int IsAsc = 0, int PageSize = 10, int SearchRecords = 1, string Alpha = "", string SearchTitle = "")
            {
                try
                {

                    if (IsArray == true)
                    {
                        foreach (string a1 in Arr)
                        {
                            if (a1.Split(':')[0].ToString() == "IsBindData")
                            {
                                IsBindData = Convert.ToInt32(a1.Split(':')[1].ToString());
                            }
                            if (a1.Split(':')[0].ToString() == "currentPageIndex")
                            {
                                currentPageIndex = Convert.ToInt32(a1.Split(':')[1].ToString());
                            }
                            if (a1.Split(':')[0].ToString() == "orderby")
                            {
                                orderby = Convert.ToString(a1.Split(':')[1].ToString());
                            }
                            if (a1.Split(':')[0].ToString() == "IsAsc")
                            {
                                IsAsc = Convert.ToInt32(a1.Split(':')[1].ToString());
                            }
                            if (a1.Split(':')[0].ToString() == "PageSize")
                            {
                                PageSize = Convert.ToInt32(a1.Split(':')[1].ToString());
                            }
                            if (a1.Split(':')[0].ToString() == "SearchRecords")
                            {
                                SearchRecords = Convert.ToInt32(a1.Split(':')[1].ToString());
                            }
                            if (a1.Split(':')[0].ToString() == "Alpha")
                            {
                                Alpha = Convert.ToString(a1.Split(':')[1].ToString());
                            }
                            if (a1.Split(':')[0].ToString() == "SearchTitle")
                            {
                                SearchTitle = Convert.ToString(a1.Split(':')[1].ToString());
                            }
                        }
                    }
                }
                catch { }

                IsArray = false;
                Arr = new string[]
                {  "IsBindData:" + IsBindData
                ,"currentPageIndex:" + currentPageIndex
                ,"orderby:" + orderby
                ,"IsAsc:" + IsAsc
                ,"PageSize:" + PageSize
                ,"Alpha:" + Alpha
                ,"SearchRecords:" + SearchRecords
                ,"SearchTitle:" + SearchTitle
                };

                int startIndex = ((currentPageIndex - 1) * PageSize) + 1;
                int endIndex = startIndex + PageSize - 1;

                if (IsBindData == 1)
                {
                    BindData = GetData(SearchRecords, SearchTitle, Alpha).OfType<RegisteredUserModel>().ToList();
                    TotalDataCount = BindData.OfType<RegisteredUserModel>().ToList().Count();
                }

                if (TotalDataCount == 0)
                {
                    StatusMessage = "NoItem";
                }

                ViewBag.IsBindData = IsBindData;
                ViewBag.CurrentPageIndex = currentPageIndex;
                ViewBag.LastPageIndex = this.getLastPageIndex(PageSize);
                ViewBag.OrderByVal = orderby;
                ViewBag.IsAscVal = IsAsc;
                ViewBag.PageSize = PageSize;
                ViewBag.SearchRecords = SearchRecords;
                ViewBag.Alpha = Alpha;
                ViewBag.SearchTitle = SearchTitle;
                ViewBag.StatusMessage = StatusMessage;
                ViewBag.name = name;
                ViewBag.pas = pas;

                var ColumnName = typeof(RegisteredUserModel).GetProperties().Where(p => p.Name == orderby).FirstOrDefault();
                //Response.Write(ColumnName);
                //Response.End();
                IEnumerable Data = null;

                if (IsAsc == 1)
                {
                    ViewBag.AscVal = 0;
                    Data = BindData.OfType<RegisteredUserModel>().ToList().OrderBy(n => ColumnName.GetValue(n, null)).Skip(startIndex - 1).Take(PageSize);
                }
                else
                {
                    ViewBag.AscVal = 1;

                    Data = BindData.OfType<RegisteredUserModel>().ToList().OrderByDescending(n => ColumnName.GetValue(n, null)).Skip(startIndex - 1).Take(PageSize);
                }

                StatusMessage = "";
                Message = "";

                return View(Data);
            }

            private int getLastPageIndex(int PageSize)
            {
                int lastPageIndex = Convert.ToInt32(TotalDataCount) / PageSize;
                if (TotalDataCount % PageSize > 0)
                    lastPageIndex += 1;

                return lastPageIndex;
            }
            private IEnumerable GetData(int SearchRecords, string SearchTitle, string Alpha)
            {
                IEnumerable RtnData = null;

                SearchTitle = SearchTitle.Trim().ToLower();
                Alpha = Alpha.Trim().ToLower();
                int id = 0;
                RtnData = (from data2 in db.GetUserDetails(id, Alpha, SearchTitle)
                           select new RegisteredUserModel
                           {
                               UserId = data2.UserId,
                               FirstName = data2.FirstName,
                               LastName = data2.LastName,
                               Email = data2.Email,
                               Country=data2.Country,
                               DateOfRegistration =data2.DateOfRegistration
                           });

                return RtnData;
            }


            public ActionResult UserDetails(int UserId = 0 )
        {
            RegisteredUser registereduser = db.RegisteredUsers.Find(UserId);
            if(registereduser== null)
            {
                return HttpNotFound();
            }

            return View(registereduser);
        }

      
        public ActionResult UserCreate()
        {
            RegisteredUserModel model = new RegisteredUserModel();
            return View(model);
        }

        [HttpPost]
        public ActionResult UserCreate(RegisteredUserModel model)
        {
            if (ModelState.IsValid)
            {
                RegisteredUser registeredUser = new RegisteredUser();
                registeredUser.FirstName = model.FirstName;
                registeredUser.LastName= model.LastName;
                registeredUser.Email= model.Email;
                registeredUser.Country = model.Country;
                registeredUser.DateOfRegistration = model.DateOfRegistration;
                
                db.RegisteredUsers.Add(registeredUser);
                db.SaveChanges();
                ViewBag.StatusMessage = "SuccessAdd";
            }
            return View(model);
        }

        public ActionResult UserEdit(int UserId = 0)
        {
            RegisteredUser registeredUser = db.RegisteredUsers.Find(UserId);
            if (registeredUser == null)
            {
                return HttpNotFound();
            }
            RegisteredUserModel model = new RegisteredUserModel();
            
            model.FirstName = registeredUser.FirstName;
            model.LastName = registeredUser.LastName;
            model.Email = registeredUser.Email;
            model.Country = registeredUser.Country;
            model.DateOfRegistration = registeredUser.DateOfRegistration;
            model.IsDeleted = registeredUser.IsDeleted;
            return View(model);
        }

        [HttpPost]
        public ActionResult UserEdit(RegisteredUserModel model)
        {
            RegisteredUser registeredUser = new RegisteredUser();

            model.FirstName = registeredUser.FirstName;
            model.LastName = registeredUser.LastName;
            model.Email = registeredUser.Email;
            model.Country = registeredUser.Country;
            model.DateOfRegistration = registeredUser.DateOfRegistration;
            db.Entry(registeredUser).State = EntityState.Modified;
            db.SaveChanges();
            ViewBag.StatusMessage = "SuccessUpdate";
            //return RedirectToAction("Index");

            return View(model);
        }

        [HttpPost, ActionName("Delete")]
        public ActionResult Delete(int UserId)
        {
            RegisteredUser registeredUser = db.RegisteredUsers.Find(UserId);
            db.RegisteredUsers.Remove(registeredUser);
            db.SaveChanges();
            return RedirectToAction("UserGrid");
        }
    }
}